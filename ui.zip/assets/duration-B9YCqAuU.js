function n(r){const t=Math.max(0,Math.round(Number(r||0))),o=a=>String(a).padStart(2,"0");return`${o(Math.floor(t/3600))}:${o(Math.floor(t%3600/60))}:${o(t%60)}`}export{n as f};
