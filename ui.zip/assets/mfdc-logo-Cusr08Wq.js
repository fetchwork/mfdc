const o="/mfdc-logo.png";export{o as _};
